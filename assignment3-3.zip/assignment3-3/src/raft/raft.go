//go:binary-only-package

package raft